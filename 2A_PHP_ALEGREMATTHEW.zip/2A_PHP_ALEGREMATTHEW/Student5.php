<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            text-align: center;
            font-family: Arial, sans-serif;
            padding: 20px;
        }
    </style>
</head>
<body>
<?php
echo "Full Name: Jhon lloyd Ajero ";
echo "<br>";

echo "Age: 20";
echo "<br>";

echo "Gender: Male";
echo "<br>";

echo "Birthday: June 7 2005";
echo "<br>";

echo "Address:  Orion, Bataan";
echo "<br>";
?>
</br>
    <a href="index.php">Back to index</a>

</body>
</html>
