<!DOCTYPE html>
  <html>
  <head>
      <title>Student Directory</title>
      <style>
      
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    text-align: center;
    color: #333;
    margin: 0;
    padding: 0;
}

h1 {
    text-align: center;
    color: #2c3e50;
    margin-bottom: 30px;
}

a{
    color: #2c3e50; 
}

</style>
  </head>
  
  <body>
    <br>
      <h1>Student Directory</h1>
      <br>
          <a href="Student1.php">About to Renz Paulo Deguzman</a>
</br>
<br>
          <a href="Student2.php">About to Vaynard Vrenz Abueg</a>
        </br>
        <br>
          <a href="Student3.php">About to Aaron Lee Herjas</a>
</br>
<br>
          <a href="Student4.php">About to Mart Keinth Balero</a>
</br>
<br>
          <a href="Student5.php">About to Jhon lloyd Ajero</a>
</br>
<br>
          <a href="Student6.php">About to Rodrianne Bantog</a>
</br>
<br>
          <a href="Student7.php">About to John Christian hernandez</a>
</br>
<br>
          <a href="Student8.php"> About to Jomarie Alberto</a>
</br>
<br>
          <a href="Student9.php"> About to Romelyn Joy Dominico</a>
</br>
<br>
          <a href="Student10.php">About to Vladymier balangat </a>
</br>
<br>
          <a href="Student11.php">About to Peyt Quitain </a>
</br>
<br>
          <a href="Student12.php">About to Juan Miguel Roxas</a>
</br>
<br>
          <a href="Student13.php"></a>
</br>
<br>
          <a href="Student14.php"></a>
</br>
<br>
          <a href="Student15.php"></a>


      </ul>
  </body>
  </html>           