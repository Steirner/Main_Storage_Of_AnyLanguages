<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            text-align: center;
            font-family: Arial, sans-serif;
            padding: 20px;
        }
    </style>
</head>
<body>
<?php
echo "Full Name: Juan Miguel Roxas";
echo "<br>";

echo "Age: 21";
echo "<br>";

echo "Gender: Male";
echo "<br>";

echo "Birthday: July 6 2004";
echo "<br>";

echo "Address:  Limay, Bataan";
echo "<br>";
?>
</br>
    <a href="index.php">Back to index</a>

</body>
</html>
