<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            text-align: center;
            font-family: Arial, sans-serif;
            padding: 20px;
        }
    </style>
</head>
<body>
<?php
echo "Full Name: Vaynard Vrenz Abueg";
echo "<br>";

echo "Age: 19";
echo "<br>";

echo "Gender: Male";
echo "<br>";

echo "Birthday: October 25 2005";
echo "<br>";

echo "Address: lower tundol Limay, Bataan";
echo "<br>";
?>
</br>
    <a href="index.php">Back to index</a>

</body>
</html>
