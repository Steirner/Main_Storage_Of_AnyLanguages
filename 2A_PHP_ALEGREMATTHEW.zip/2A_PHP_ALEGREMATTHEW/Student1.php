<!DOCTYPE html>
<html>
<head>
    <style>
          body {
            text-align: center;
            font-family: Arial, sans-serif;
            padding: 20px;
          }
        
    </style>
</head>
<body>
<?php
echo "Full Name: Renz Paulo Deguzman";
echo "<br>";

echo "Age: 22";
echo "<br>";

echo "Gender: Male";
echo "<br>";

echo "Birthday: September 10 2002";
echo "<br>";

echo "Address: Lamao Limay, Bataan";
echo "<br>";
?>
<br>
    <a href="index.php">Back to index</a>
    </br>

</body>
</html>
