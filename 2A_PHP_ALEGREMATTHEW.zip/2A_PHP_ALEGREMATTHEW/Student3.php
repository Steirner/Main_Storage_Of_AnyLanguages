<!DOCTYPE html>
<html>
<head>
    <title>Student Directory</title>
    <style>
        body {
            text-align: center;
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        
    </style>
</head>
<body>
<?php
echo "Full Name: Aaron Lee Herjas";
echo "<br>";

echo "Age: 19";
echo "<br>";

echo "Gender: Male";
echo "<br>";

echo "Birthday: May 14, 2006";
echo "<br>";

echo "Address: Duale Limay, Bataan";
echo "<br>";
?>
</br>
    <a href="index.php">Back to index</a>

</body>
</html>
